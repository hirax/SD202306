__doc__ = '''Libs that I had to backport to make my life easier'''
