# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

import rubicon_objc

UIScreen = rubicon_objc.api.ObjCClass('UIScreen')
main_screen = UIScreen.mainScreen

if __name__ == '__main__':
    import time
    for i in range(10):
        print( main_screen.brightness )
        time.sleep(1)


