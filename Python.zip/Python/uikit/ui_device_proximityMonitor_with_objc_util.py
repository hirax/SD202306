# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

from objc_util import *
import ctypes

UIKit = ctypes.cdll.LoadLibrary(
  "/System/Library/Frameworks/UIKit.framework/UIKit"
)
UIDevice = ObjCClass('UIDevice')
UIDevice_currentDevice_ = UIDevice.currentDevice()

if __name__ == '__main__':
    from uikit.ui_device_proximityMonitor import*
    import time
    
    
