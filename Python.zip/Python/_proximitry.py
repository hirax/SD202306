from uikit.ui_device_proximityMonitor import*
import time

# こっちは実行すると落ちる　なぜ？
#UIDevice_currentDevice_.proximityMonitoringEnabled = True
# これはゲッタ
#UIDevice_currentDevice_.isProximityMonitoringEnabled = True
# これはセッター、Trueを入れると落ちる、False だと落ちない
UIDevice_currentDevice_.setProximityMonitoringEnabled(False)

# こっちは動く
UIDevice_currentDevice_.batteryMonitoringEnabled = True

print(UIDevice_currentDevice_.systemVersion)
print(UIDevice_currentDevice_.orientation)
print(UIDevice_currentDevice_.batteryLevel)

print(UIDevice_currentDevice_.isProximityMonitoringEnabled())
print("----")
for i in range(10):
    print(UIDevice_currentDevice_.proximityState)
    time.sleep(1)
