# https://gist.github.com/jsbain/2cf4998949f49b58ff284239784e1561


from rubicon.objc import api as rubicon_api
import ctypes
import io
import numpy as np
#import time

# フレームワークを読み込む
AVFoundation = ctypes.cdll.LoadLibrary(
  "/System/Library/Frameworks/AVFoundation.framework/AVFoundation"
)
AudioToolbox = ctypes.cdll.LoadLibrary(
  "/System/Library/Frameworks/AudioToolbox.framework/AudioToolbox"
)

# AVAudio 関係のクラスを読み込む
AVAudioEngine = rubicon_api.ObjCClass('AVAudioEngine')
AVAudioSession = rubicon_api.ObjCClass('AVAudioSession')
AVAudioPCMBuffer = rubicon_api.ObjCClass('AVAudioPCMBuffer')
AVAudioFormat = rubicon_api.ObjCClass('AVAudioFormat')
AVAudioSourceNode = rubicon_api.ObjCClass('AVAudioSourceNode')

'''
AVAudioPlayerNode = rubicon_api.ObjCClass('AVAudioPlayerNode')
AVAudioFile = rubicon_api.ObjCClass('AVAudioFile')
AVAudioUnitEQ = rubicon_api.ObjCClass('AVAudioUnitEQ')
AVAudioMixerNode = rubicon_api.ObjCClass('AVAudioMixerNode')
AVAudioUnitEQFilterParameters = rubicon_api.ObjCClass('AVAudioUnitEQFilterParameters')
AVAudioSessionPortDescription = rubicon_api.ObjCClass('AVAudioSessionPortDescription')
AVAudioCompressedBuffer = rubicon_api.ObjCClass('AVAudioCompressedBuffer')
AVAudioConverter = rubicon_api.ObjCClass('AVAudioConverter')
AVAudioTime = rubicon_api.ObjCClass('AVAudioTime')
'''

CHANNEL = 1  # kVariableLengthArray のこと（interleaved ならステレオでも1のまま）
# AudioBuffer: 音声データを格納するバッファー（構造体）
class AudioBuffer( ctypes.Structure ):
    _fields_ = [
        ('mNumberChannels', ctypes.c_uint32), # チャンネル数 # ステレオなら2
        ('mDataByteSize', ctypes.c_uint32),   # mData領域のサイズ # ステレオInterleavedだと×2
        ('mData', ctypes.c_void_p),           # 音声データ        # ステレオInterleavedだと×2
    ]

# AudioBufferList: AudioBuffer のリスト
class AudioBufferList( ctypes.Structure ):
    _fields_ = [
        ('mNumberBuffers', ctypes.c_uint32), # AudioBufferの配列数
        ('mBuffers', AudioBuffer * CHANNEL), # AudioBufferの配列 # non-interleavedでは対応してない
#        ('mBuffers', AudioBuffer * CHANNEL), # AudioBufferの配列 # non-interleavedでは対応してない
    ]
  
'''
class AudioStreamBasicDescription(ctypes.Structure):
    _fields_=[
    ('mSampleRate',ctypes.c_double),
    ('mFormatID',ctypes.c_uint32),
    ('mFormatFlags',ctypes.c_uint32),
    ('mBytesPerPacket',ctypes.c_uint32),
    ('mFramesPerPacket',ctypes.c_uint32),
    ('mBytesPerFrame',ctypes.c_uint32),
    ('mChannelsPerFrame',ctypes.c_uint32),
    ('mBitsPerChannel',ctypes.c_uint32),
    ('mReserved',ctypes.c_uint32)
    ]
'''

# 音声波形生成関数
def rendering_function(t, channel):
    if channel == 1:
        val = 1.0 * math.sin(440.0 * 2.0 * math.pi * t)
        return [val]
    else:
        val1 = 1.0 * math.sin(440.0 * 2.0 * math.pi * t)
        val2 = 1.0 * math.sin(440.0 * 2.0 * math.pi * t)
        return [val1, val2]

class AVAudioNodeTapBlock_Capture:

    # コンストラクタ
    def __init__( self,
                  buffer_size,
                  user_capture_function,   # 取得用関数
                  user_rendering_function, # 出力用関数
                  channels                 # チャンネル数
                ):
    
        # 音声取得を行う際のバッファーサイズを設定
        self.buffer_size = buffer_size
        # リアルタイムに得たデータに処理をさせる「ユーザー関数」
        self.user_capture_function = user_capture_function
        # リアルタイムに音声データを生成する「ユーザー関数」
        self.user_rendering_function = user_rendering_function
        
        # 音声の再生・録音ができるモードで、AVAudioEngineを作る
        error = rubicon_api.objc_id(0)
        session = AVAudioSession.sharedInstance()
        category = session.setCategory(
                   'AVAudioSessionCategoryPlayAndRecord',
                   error = ctypes.pointer(error) )
        if error:
            raise Exception('error setting up category')
        # セッションをアクティブにする
        session.setActive( True, error=ctypes.pointer(error) )
        if error:
            raise Exception( 'error setting up session active' )
            
        # AVAudioEngine を作成
        self.AVAudioEngine = AVAudioEngine.new()

        # ---------- マイク入力を音声取得する（ここから） ------------
        # 音声キャプチャ処理をするBlocks用関数を
        # buffer_sizeやuser_capture_functionを使ったクロージャとして定義
        # 実行スレッドはメインスレッドとは限らない
        def capture_block_function(                   # AVAudioNodeTapBlock
                  buffer: ctypes.c_void_p,            # AVAudioPCMBuffer
                  when:   ctypes.c_void_p ) -> None:  # AVAudioTime
            try:
                # AVAudioPCMBuffer を取得
                audio_in_buf = rubicon_api.ObjCInstance(buffer)
                # AVAudioPCMBufferの値をnumpyアレイとして読み込む
                nparray_audio = np.ctypeslib.as_array(
                      #
                      audio_in_buf.floatChannelData[0],
                      (buffer_size, 1) )     # buffer_sizeの1次元リストで受け取る(2次元にはしない)
                # 音声データをユーザー関数に受け渡す
                self.user_capture_function(nparray_audio)
                pass
            except:
                raise
        # AudioEngineの暗黙入力ノード(inputNode)はマイク入力
        # マイク入力にタップを付けて音声データをキャプチャする
        input_node = self.AVAudioEngine.inputNode
        try:
            input_node.installTapOnBus_bufferSize_format_block_(
                0,                                 # inputNode(index:0)の出力バスにタップ
                buffer_size,                       # バッファーサイズ:AVAudioFrameCount
                input_node.outputFormatForBus_(0), # 出力フォーマットを指定:AVAudioFormat
                                                   # この例(設定そのまま)では、Noneを指定しても良い
                capture_block_function )           # 呼び出される関数 (AVAudioNodeTapBlock)
            pass
        except:
            print('Can not install AVAudioNodeTapBlock.')
            raise
        # ---------- マイク入力を音声取得する（ここまで） ------------

        # ---------- 音声出力する（ここから） ------------
        
        # 音声生成用のノードを作る
        source_node = AVAudioSourceNode.alloc()
        # 暗黙の出力ノード（デフォルト出力）
        output_node = self.AVAudioEngine.outputNode
        # 暗黙のMixerノード
        mixer_node = self.AVAudioEngine.mainMixerNode

        # 経過時間
        self.time = 0.0

        # 出力側にとって（入力として）必要な音声フォーマット
        # これでも動く
        # format_for_output_node = output_node.inputFormatForBus(0) #
        # これでも動くみたい
        format_for_output_node = mixer_node.inputFormatForBus(0) #
        
        self.sampleRate = format_for_output_node.sampleRate       #
        self.delta_time = 1 / self.sampleRate
        
        # 下記は出力側のチャンネル数 (2)←使わない
        #print( "Channel:{:1d}".format( format_for_output_node.channelCount ))

        # 出力フォーマットを作る
        format_for_output = AVAudioFormat.alloc().initWithCommonFormat_sampleRate_channels_interleaved_(
            format_for_output_node.commonFormat,
            self.sampleRate,
            channels,                              # チャンネル数
            format_for_output_node.isInterleaved ) # Interleaved（交互）か？

        # 音声出力用の AVAudioSourceNodeRenderBlock を作る
        def render_block_function(
                is_silence: ctypes.c_void_p,           # Boolean
                timestamp:  ctypes.c_void_p,           # HAL time
                frame_count: ctypes.c_void_p,          # エンジンが要求したフレーム数
                buffer_p:   ctypes.c_void_p ) -> None: # ctypes.POINTER では自動型変換できない
                                                       # buffer_p,ctypes.POINTER(AudioBufferList)
            # AudioBufferListとして受け取る
            audio_buffer_list = ctypes.cast( buffer_p,
                                             ctypes.POINTER(AudioBufferList) ).contents
            # 要求フレーム数分のデータを作る:長さ方向
            #print("frame_count:{:d}".format(frame_count))
            #print("mNumberBuffers:{:d}".format(audio_buffer_list.mNumberBuffers))
            for frame in range(frame_count):
                # 値を計算（外部関数で与える）
                val = self.user_rendering_function( self.time, channels )
                self.time += self.delta_time
                # AudioBufferList に書き込む：バッファー数方向
                for i in range( audio_buffer_list.mNumberBuffers ):
                    # 各Bufferのアドレスを指す場所に飛ぶ
                    # 「各Bufferごと丸っとまとめたサイズ」でcastして先頭に飛ぶ（ワイルドだ）
                    if channels == 1:
                        mData = audio_buffer_list.mBuffers[i].mData
                        pointer = ctypes.POINTER( ctypes.c_float * frame_count )
                        buffer = ctypes.cast( mData, pointer ).contents
                        buffer[frame] = val[0]     # 値を設定する
                    #else: # 2
                    #    buffer[2*frame] = val[0]   # 値を設定する
                    #    buffer[2*frame+1] = val[1] # 値を設定する

        # source_nodeの処理として、AVAudioSourceNodeRenderBlock を登録する
        source_node.initWithFormat_renderBlock_( # ★
            format_for_output,         # AVAudioFormat
            render_block_function )    # AVAudioSourceNodeRenderBlock
        
        # AVAudioEngineにsource_node を追加する
        self.AVAudioEngine.attachNode(source_node) # ★
        #source_node.volume = 1.0  # これ動くのかな？必要かな？
        
        # 処理順番の指定：source_node -> mixer_node と繋ぐ
        #　この処理をすると、落ちるかどうかが決まる
        self.AVAudioEngine.connect_to_format_(source_node, mixer_node, format_for_output) # ★
        
        # 処理順番の指定：mixer_node -> output_node と繋ぐ(不要)
        # 暗黙のミキサーと出力はデフォルトで繋がれている
        #sself.AVAudioEngine.connect_to_format_(mixer_node, output_node, format_for_output)
        # ---------- 音声出力する（ここまで） ------------

    # 音声処理をするための準備動作をさせる
    def prepare(self):
        self.AVAudioEngine.prepare()
    
    # 音声処理を開始する
    def start(self):
        self.AVAudioEngine.startAndReturnError_(None)
    
    # 音声処理を停止する
    def stop(self):
        self.AVAudioEngine.stop()
    
    # AVAudioEngineをリセットする
    def reset(self):
        AVAudioEngine_.reset()

#######################


AVAudioEngine_ = None
#audio_in_buf = []
#image_convert_bIO = io.BytesIO()
#lastt = 0

BUFFER_SIZE = 4096

# AVAudioEngine を返す
def setup():
    # AVAudioSessionを作成・設定する
    error = rubicon_api.objc_id(0) # Objc_utilならctypes.c_void_p(0)
    session = AVAudioSession.sharedInstance()
    category = session.setCategory(
                   'AVAudioSessionCategoryPlayAndRecord',
                   error = ctypes.pointer(error)
               )
    if error:
        raise Exception('error setting up category')
    session.setActive( True, error=ctypes.pointer(error) )
    if error:
        raise Exception( 'error setting up session active' )
    # AVAudioEngineを作成
    engine = AVAudioEngine.new()
    return engine

# オーディオ処理をするBlocks用関数 (AVAudioNodeTapBlock)
def capturte_block_function(
                  buffer: ctypes.c_void_p,            # AVAudioPCMBuffer
                  when:   ctypes.c_void_p ) -> None:  # AVAudioTime
    try:
        # AVAudioPCMBuffer
        audio_in_buf = rubicon_api.ObjCInstance(buffer)
        # AVAudioPCMBufferの値をnumpyアレイとして読み込む
        A = np.ctypeslib.as_array(
              # AVAudioPCMBuffer * で渡されるので[0]つける
              audio_in_buf.floatChannelData[0],
              (BUFFER_SIZE,1)
        )
        print(A)
        pass
    except:
        raise

def setup_audio_input_engine():
    global AVAudioEngine_
    # AudioEngine を作成
    AVAudioEngine_ = setup()
    mixer = AVAudioEngine_.mainMixerNode
    input = AVAudioEngine_.inputNode
    try:
        # マイク入力を表す暗黙入力に、AVAudioNodeTapBlockをタップする
        input.installTapOnBus_bufferSize_format_block_(
            0,                             # AVAudioNodeBus
            BUFFER_SIZE,                   # AVAudioFrameCount
            input.outputFormatForBus_(0),  # AVAudioFormat
            process_block_function )       # AVAudioNodeTapBlock
        pass
    except:
        print('Can not install.')
        raise
    AVAudioEngine_.prepare()
    print("Setup is done.")

def start_audio_input_engine():
    global AVAudioEngine_
    AVAudioEngine_.startAndReturnError_(None)

def stop_audio_input_engine():
    global AVAudioEngine_
    AVAudioEngine_.stop()
    AVAudioEngine_.reset()

