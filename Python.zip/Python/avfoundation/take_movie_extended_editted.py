
from objc_util import *
import ctypes
from uikit.ui_uiview import *
import numpy as np
import copy
from uikit.ui_uiimage_convert import *
import time

from defines import *

NSDictionary = ObjCClass('NSDictionary')
NSMutableDictionary = ObjCClass('NSMutableDictionary')

AVCaptureSession = ObjCClass('AVCaptureSession')
AVCaptureDevice = ObjCClass('AVCaptureDevice')
AVCaptureDeviceInput = ObjCClass('AVCaptureDeviceInput')
AVCaptureVideoDataOutput = ObjCClass('AVCaptureVideoDataOutput')
AVCaptureVideoPreviewLayer = ObjCClass('AVCaptureVideoPreviewLayer')
AVCaptureConnection = ObjCClass('AVCaptureConnection')
AVCaptureDeviceDiscoverySession = ObjCClass('AVCaptureDeviceDiscoverySession')

# https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturedevicetype?view=xamarin-ios-sdk-12
BuiltInMicrophone  =  0
BuiltInTelephotoCamera  =  2
#BuiltInDuoCamera  =  3
BuiltInDualCamera  =  4
BuiltInTrueDepthCamera  =  5

# VideoOrientation
AVCaptureVideoOrientationPortrait = 1
AVCaptureVideoOrientationPortraitUpsideDown = 2
AVCaptureVideoOrientationLandscapeRight = 3
AVCaptureVideoOrientationLandscapeLeft = 4
# FocusMode
AVCaptureFocusModeLocked = 0
AVCaptureFocusModeAutoFocus = 1
AVCaptureFocusModeContinuousAutoFocus = 2
# ExposureMode
AVCaptureExposureModeLocked = 0
AVCaptureExposureModeAutoExpose = 1
AVCaptureExposureModeContinuousAutoExposure = 2
AVCaptureExposureModeCustom = 3
# WhiteBalanceMode
AVCaptureWhiteBalanceModeLocked = 0
AVCaptureWhiteBalanceModeAutoWhiteBalance = 1
AVCaptureWhiteBalanceModeContinuousAutoWhiteBalance = 2
# TorchMode
AVCaptureTorchModeOff = 0
AVCaptureTorchModeOn = 1
AVCaptureTorchModeAuto = 2

# dispatch_get_current_queue 関数のポインタ指定、引数型はvoid・返値型定義
dispatch_get_current_queue = c.dispatch_get_current_queue
dispatch_get_current_queue.restype = c_void_p
# CMSampleBufferGetImageBuffer 関数のポインタ指定、引数型・返値型定義
CMSampleBufferGetImageBuffer = c.CMSampleBufferGetImageBuffer
CMSampleBufferGetImageBuffer.argtypes = [c_void_p]
CMSampleBufferGetImageBuffer.restype = c_void_p
# CVPixelBufferLockBaseAddress 関数のポインタ指定、引数型・返値型定義
CVPixelBufferLockBaseAddress = c.CVPixelBufferLockBaseAddress
CVPixelBufferLockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferLockBaseAddress.restype = None
# CVPixelBufferUnlockBaseAddress 関数のポインタ指定、引数型・返値型定義
CVPixelBufferUnlockBaseAddress = c.CVPixelBufferUnlockBaseAddress
CVPixelBufferUnlockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferUnlockBaseAddress.restype = None

# PixelBuffer Definitions
CVPixelBufferGetWidthOfPlane = c.CVPixelBufferGetWidthOfPlane
CVPixelBufferGetWidthOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetWidthOfPlane.restype = ctypes.c_int

CVPixelBufferGetHeightOfPlane = c.CVPixelBufferGetHeightOfPlane
CVPixelBufferGetHeightOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetHeightOfPlane.restype = ctypes.c_int

CVPixelBufferGetBaseAddressOfPlane = c.CVPixelBufferGetBaseAddressOfPlane
CVPixelBufferGetBaseAddressOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetBaseAddressOfPlane.restype = ctypes.c_void_p

CVPixelBufferGetBytesPerRowOfPlane = c.CVPixelBufferGetBytesPerRowOfPlane
CVPixelBufferGetBytesPerRowOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetBytesPerRowOfPlane.restype = ctypes.c_int

class CMTime(ctypes.Structure):
    _fields_ = [
                ('CMTimeValue', ctypes.c_int64),
                ('CMTimeScale', ctypes.c_int32),
                ('CMTimeEpoch', ctypes.c_int64),
                ('CMTimeFlags', ctypes.c_uint32),
                ]
                
def CMTimeMake(value, scale):
    cm = CMTime()
    cm.CMTimeScale = scale
    cm.CMTimeValue = value
    return cm

UIImage = ObjCClass('UIImage')
CIImage = ObjCClass('CIImage')

AVCaptureDeviceTypeExternalUnknown = 'AVCaptureDeviceTypeExternalUnknown'
AVCaptureDeviceTypeBuiltInMicrophone = 'AVCaptureDeviceTypeBuiltInMicrophone'
AVCaptureDeviceTypeBuiltInWideAngleCamera = 'AVCaptureDeviceTypeBuiltInWideAngleCamera'
AVCaptureDeviceTypeBuiltInTelephotoCamera = 'AVCaptureDeviceTypeBuiltInTelephotoCamera'
AVCaptureDeviceTypeBuiltInUltraWideCamera = 'AVCaptureDeviceTypeBuiltInUltraWideCamera'
AVCaptureDeviceTypeBuiltInDualCamera = 'AVCaptureDeviceTypeBuiltInDualCamera'
AVCaptureDeviceTypeBuiltInDualWideCamera = 'AVCaptureDeviceTypeBuiltInDualWideCamera'
AVCaptureDeviceTypeBuiltInTripleCamera = 'AVCaptureDeviceTypeBuiltInTripleCamera'
AVCaptureDeviceTypeBuiltInTrueDepthCamera = 'AVCaptureDeviceTypeBuiltInTrueDepthCamera'
AVCaptureDeviceTypeBuiltInDuoCamera = 'AVCaptureDeviceTypeBuiltInDuoCamera'
AVCaptureDeviceTypeBuiltInLiDARDepthCamera = 'AVCaptureDeviceTypeBuiltInLiDARDepthCamera'

BuiltInMicrophone  =  0
BuiltInTelephotoCamera  =  2
#BuiltInDuoCamera  =  3
BuiltInDualCamera  =  4
BuiltInTrueDepthCamera  =  5

# AVCaptureDevicePosition
AVCaptureDevicePositionBack = 1  # AVCaptureDevicePositionUnspecified = 0?
AVCaptureDevicePositionFront = 2

# 下記多分間違ってる
AVMediaTypeVideo = 0
AVMediaTypeAudio = 1
AVMediaTypeText = 2
AVMediaTypeClosedCaption = 3
AVMediaTypeSubtitle = 4
AVMediaTypeTimecode = 5
AVMediaTypeMetadata = 6
AVMediaTypeMuxed = 7

#main_view = None
session = None
delegate = None
output = None
processed_frames = 0
images = []
_ui_view = None
ui_imageview = None
epoch_time = None
frame_duration = 0.1
user_func = None   # ユーザーにnpimageを処理させる関数

# 処理画像を表示させるための関数
@on_main_thread
def update_image(ui_imageview,image):
    # UIImageViewのimageを更新する
    ui_imageview.image = np2ui( image )
    ui_imageview.setNeedsLayout()

# delegateから呼ばれる処理関数
def processPixelBuffer(pixelData):
    global images, ui_imageview, user_func
    base_address  = CVPixelBufferGetBaseAddressOfPlane(pixelData, 0)
    bytes_per_row = CVPixelBufferGetBytesPerRowOfPlane(pixelData, 0)
    # サイズを取得
    width = CVPixelBufferGetWidthOfPlane(pixelData, 0)
    height = CVPixelBufferGetHeightOfPlane(pixelData, 0)
    
    # YUV_420_888のYだけを取得する場合
    #image = np.ctypeslib.as_array(
    #    ctypes.cast(base_address, ctypes.POINTER(ctypes.c_ubyte)),
    #    shape=((height, width)) )
    # BGRAで取得する場合
    image = np.ctypeslib.as_array(
        ctypes.cast(base_address, ctypes.POINTER(ctypes.c_ubyte)),
        shape=((height, width*4)) )
    # 廃棄防止をした上で、ユーザー関数を呼ぶ
    np_img = copy.copy(image); user_func(np_img)
    #update_image(ui_imageview, np_img) # np_img⇒UIImage⇒ui_imageview
    update_image(ui_imageview, np_img[:,::4]) # np_img⇒UIImage⇒ui_imageview

# delegate を書く
def captureOutput_didOutputSampleBuffer_fromConnection_(
              _self, _cmd, _output, _sample_buffer, _conn):
    global processed_frames, epoch_time, frame_duration
    # iOSのフレームレート設定が面倒なので、手抜き実装
    if time.time() - epoch_time > frame_duration:
        epoch_time = time.time()
        # サンプルバッファを読み込む
        _imageBuffer = CMSampleBufferGetImageBuffer(_sample_buffer)
        # サンプルバッファをロック
        CVPixelBufferLockBaseAddress(_imageBuffer, 0)
        # 具体的な処理をさせる関数を呼ぶ
        processPixelBuffer(_imageBuffer)
        # サンプルバッファをアンロック
        CVPixelBufferUnlockBaseAddress(_imageBuffer, 0)
        processed_frames = processed_frames + 1

# delegate を登録する
sampleBufferDelegate = create_objc_class(
    'sampleBufferDelegate',
    methods=[captureOutput_didOutputSampleBuffer_fromConnection_],
    protocols=['AVCaptureVideoDataOutputSampleBufferDelegate'])

# セットアップ
@on_main_thread
def video_shooting_setup( ui_view, captureDeviceType, sessionPreset, pixel_format_type, func):
    global session, delegate, output, _ui_view, ui_imageview, user_func
    
    _ui_view = ui_view # モジュール内Global変数に格納しておく
    user_func = func
    
    # デバイスを開く
    captureDeviceDiscoverySession = AVCaptureDeviceDiscoverySession.discoverySessionWithDeviceTypes_mediaType_position_(
    
        [ captureDeviceType ], 'vide', 1)  # AVMediaTypeVideo,AVCaptureDevicePositionBack
    captureDevices = captureDeviceDiscoverySession.devices()
    device = captureDevices[0] # 該当する最初のデバイスを選択
    _input = AVCaptureDeviceInput.deviceInputWithDevice_error_(device, None)
    if _input:
        session = AVCaptureSession.alloc().init()
        session.addInput_(_input)
    else:
        return
    # AVCaptureVideoDataOutput を作成
    output = AVCaptureVideoDataOutput.alloc().init()
    #output.videoSettings = { kCVPixelBufferPixelFormatTypeKey:CV32BGRA }
    if pixel_format_type is not None:
        output.videoSettings = { kCVPixelBufferPixelFormatTypeKey:pixel_format_type }
    
    print("videoSettings()")
    print(output.videoSettings())
    
    # デバイス設定をロック
    device.lockForConfiguration_(None)
    # フォーカス設定
    device.focusMode = AVCaptureFocusModeLocked
    device.setFocusModeLockedWithLensPosition_completionHandler_( 0.5, None )
    # デバイス設定をアンロック
    device.unlockForConfiguration()
    
    # 画像を取得するdelegateとqueueを設定
    delegate = sampleBufferDelegate.new() # 作成済みのdelegate用クラス
    queue = ObjCInstance( dispatch_get_current_queue() )
    output.setSampleBufferDelegate_queue_( delegate, queue )
    # didOutputSampleBufferを処理中、さらに撮影されたフレームは廃棄
    output.alwaysDiscardsLateVideoFrames = True
    
    # session に output を接続
    session.addOutput_(output)
    
    # https://dev.classmethod.jp/articles/ios-avfoundation/
    session.beginConfiguration()
    session.sessionPreset = sessionPreset #'AVCaptureSessionPreset3840x2160' # 'AVCaptureSessionPreset640x480'
    session.commitConfiguration()

    # 表示用のui_viewを追加
    main_view = get_view_controllers()[1].view()
    add_uiview_to_mainview(ui_view, main_view)
    # UIImageViewをui_viewに追加しておく
    ui_imageview = UIImageView.alloc().init()
    ui_imageview.frame = _ui_view.bounds()
    add_uiview_to_mainview( ui_imageview, _ui_view )
    processed_frames = 0

# カメラ撮影をスタートさせる
@on_main_thread
def video_shooting_start(frameDuration):
    global session, processed_frames, epoch_time, frame_duration
    epoch_time = time.time()
    frame_duration = frameDuration
    session.startRunning()
    processed_frames = 0

# カメラ撮影を終了させる
@on_main_thread
def video_shooting_close(ui_view):
    global session, delegate, output, processed_frames
    session.stopRunning()
    delegate.release()
    session.release()
    output.release()
    # プレビューレイヤーを消す（Noneにはしない）
    remove_uiview_fromsuper(ui_view)
    print( "processed_frames:{}".format(processed_frames))
