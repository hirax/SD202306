# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

# Obj-Cクラス読み込み
from classes.header import *

import ctypes
import rubicon
import ctypes

from rubicon.objc import NSObject, ObjCProtocol, objc_method
from ctypes import c_void_p, cast
import time, threading
import os
import numpy as np


# ===================  マニュアル撮影クラス(作成・即実行) ===================
def manualCapture(
      captureDeviceType,  # カメラのデバイスタイプ
      orientation,
      exposureMode, # AVCaptureExposureModeLocked/AVCaptureExposureModeAutoExpose/AVCaptureExposureModeContinuousAutoExposure/AVCaptureExposureModeCustom
      # The maximum exposure time: iPhone 6 is 1/2 second, 1/3 on iPhone 6s
                  # 1/15, 1/25, 1/45, 1/90, 1/190, 1/380
      exposureValue, exposureScale,  # value/scale (seconds) (CMTimeValue:value = Int62, CMTimeScale:scale = Int32)
      iso,           # min 23 - max 736
      focusMode,     # AVCaptureFocusModeLocked/AVCaptureFocusModeAutoFocus/AVCaptureFocusModeContinuousAutoFocus
      focusDistance, # 0.0 - 1.0
      temperatureAndTint,  # [temprature(kelvin), tint=white balance(-150.0 to +150.0)] ex.[6000.0, 0.0]
      torch,         # [AVCaptureTorchModeOff/AVCaptureTorchModeOn/AVCaptureTorchModeAuto, level(0.0-1.0)]
      fileName,      # fileName used in saving
      albumName,     # album name. if None, image isn't stored to album
      imageFormat,   # '.JPG', '.DNG'
      isSaveNPY ):   # numpy データをマーシャルダンプするか：True, False
    
    # .......... 独自の処理をしたい時のために用意した関数  ..................................
    def processPixelBuffer(pixelData, fileName):
        # PythonでバイナリをあつかうためのTips
        # https://qiita.com/pashango2/items/5075cb2d9248c7d3b5d4
        base_address  = CVPixelBufferGetBaseAddressOfPlane(pixelData, 0)
        bytes_per_row = CVPixelBufferGetBytesPerRowOfPlane(pixelData, 0)
        width = CVPixelBufferGetWidthOfPlane(pixelData, 0)
        height = CVPixelBufferGetHeightOfPlane(pixelData, 0)
        data = np.ctypeslib.as_array( ctypes.cast( base_address, ctypes.POINTER( ctypes.c_ushort ) ),
                                      shape=( (height, width) ))
        r = data[::2, ::2]
        g = (data[1::2, ::2] + data[::2, 1::2])/2 # G画素値は平均にしちゃう
        b = data[1::2, 1::2];
        # 複数numpyアレイ(r,g,b)をまとめてnpzで保存
        np.savez(fileName+'.npz', r=r, g=g, b=b)
        # 各色のnumpyアレイを、それぞれ保存したい時はこっち
        #np.save(fileName+'.r.npy', r); np.save(fileName+'.g.npy', g); np.save(fileName+'.b.npy', b)
    
    # .......... delegate method(共通) 206行で登録..........
    def captureOutput_didFinishProcessingPhoto_error_(_self, _cmd, _output, _photoBuffer, _error):
        # バッファ, 画像取得, ファイル保存
        photoBuffer = rubicon.objc.api.ObjCInstance(_photoBuffer)
        if not photoBuffer:
            return
        # 画像を保存
        fileData = photoBuffer.fileDataRepresentation()
        if not fileData:
            print( 'we have no fileDataRepresentation for '+ fileName )
            return
        fileData.writeToFile_atomically_( fileName, True )
        #print(fileName)
        # アルバム保存（アルバムネームがNoneで無かったら）
        if albumName:
            addImagefileToAlbum( fileName, albumName )
            # アルバム登録時はカレントディレクトリのファイルは削除する
            os.remove( fileName )
        # raw 画像が指定されていて、numpy保存指定がされていたら
        if '.DNG' == imageFormat and isSaveNPY:
            _pixelData = photoBuffer.pixelBuffer()
            if not _pixelData:
                return
            CVPixelBufferLockBaseAddress( _pixelData, 0 )
            processPixelBuffer( _pixelData, fileName )
            CVPixelBufferUnlockBaseAddress( _pixelData, 0 )
        event.set()
    
    AVFoundation = cdll.LoadLibrary("/System/Library/Frameworks/AVFoundation.framework/AVFoundation")

    c = cdll.LoadLibrary(None)
    objc_getProtocol = c.objc_getProtocol
    objc_getProtocol.restype = ctypes.c_void_p
    objc_getProtocol.argtypes = [ctypes.c_char_p]
    AVCapturePhotoCaptureDelegate = objc_getProtocol( ('AVCapturePhotoCaptureDelegate').encode('ascii') )
    print(AVCapturePhotoCaptureDelegate)
    class CameraManualPhotoCaptureDelegate( NSObject ):
    
        @objc_method
        def captureOutput_didFinishProcessingPhoto_error_(_self, _cmd, _output, _photoBuffer, _error):
            print("called.")
            # バッファ, 画像取得, ファイル保存
            photoBuffer = ObjCInstance( _photoBuffer )
            if not photoBuffer:
                return
            # 画像を保存
            fileData = photoBuffer.fileDataRepresentation()
            if not fileData:
                print('we have no fileDataRepresentation for '+ fileName)
                return
            fileData.writeToFile_atomically_(fileName, True)
            # アルバム保存（アルバムネームがNoneで無かったら）
            if albumName:
                addImagefileToAlbum(fileName, albumName)
                # アルバム登録時はカレントディレクトリのファイルは削除する
                os.remove(fileName)
            # raw 画像が指定されていて、numpy保存指定がされていたら
            if '.DNG'==imageFormat and isSaveNPY:
                _pixelData = photoBuffer.pixelBuffer()
                if not _pixelData:
                    return
                CVPixelBufferLockBaseAddress(_pixelData,0)
                processPixelBuffer(_pixelData, fileName)
                CVPixelBufferUnlockBaseAddress(_pixelData,0)
            event.set()

    # ......................　デバイス設定 .........................................
    # デバイス選択
    captureDeviceDiscoverySession = AVCaptureDeviceDiscoverySession.discoverySessionWithDeviceTypes_mediaType_position_(
        [ captureDeviceType ], # AVCaptureDeviceTypeBuiltInWideAngleCamera
        AVMediaTypeVideo,
        AVCaptureDevicePosition.Back )

    captureDevices = captureDeviceDiscoverySession.devices
    print("Available camera(s): "+str( len( captureDevices ) ) )
    device = captureDevices[0]
    
    # デバイスの設定を開始
    device.lockForConfiguration_(None)

    # exposureMode lock/unlock
    if exposureMode and device.isExposureModeSupported_(exposureMode):
        device.exposureMode = exposureMode

    while(not device.isAdjustingExposure): # 設定を待つ
        time.sleep(0.1)

    #focus distance and mode  ( 0.0 - 1.0 )
    if focusDistance and focusMode == AVCaptureFocusMode.Locked:
        device.setFocusModeLockedWithLensPosition_completionHandler_(focusDistance, None)
    # focus distance and mode
    if AVCaptureTorchMode.Off != torch[0] and device.hasTorch():
        device.torchMode = torch[0]
        device.setTorchModeOnWithLevel_error_(torch[1], None)
    device.unlockForConfiguration()
    time.sleep(0.2)

    # ....... create input, output, and session .......
    _input = AVCaptureDeviceInput.deviceInputWithDevice_error_(device, None)
    photoOutput = AVCapturePhotoOutput.alloc().init()
    time.sleep(0.2)  # デバイスが開かれるのに時間がかかるのでwait

    # AVCaptureSessionを開始
    session = AVCaptureSession.alloc().init()
    session.beginConfiguration()
    session.sessionPreset = 'AVCaptureSessionPresetPhoto'
    if _input:
        session.addInput_(_input)
    else:
        print('Failed to get AVCaptureDeviceInput.')
        return
    if photoOutput:
        session.addOutput_(photoOutput)
    else:
        print('Failed to get AVCapturePhotoOutput.')
        return
    session.commitConfiguration()
    session.startRunning()
    time.sleep(0.2)
    
    print(photoOutput)
    #availableRawPhotoPixelFormatTypes = photoOutput.availableRawPhotoPixelFormatTypes()
    availableRawPhotoPixelFormatTypes = photoOutput.availableRawPhotoPixelFormatTypes
    availableRawPhotoPixelFormatType = int('{}'.format(availableRawPhotoPixelFormatTypes[0]))

    # settings
    settings = None
    if imageFormat == '.DNG': # bayer_RGGB14←OSTypedEnumとしては=1919379252
        settings = AVCapturePhotoSettings.photoSettingsWithRawPixelFormatType( availableRawPhotoPixelFormatType )
    if imageFormat == '.JPG':  # JPGとは限らず、保存設定に準ずる、の動作をするはず
        settings = AVCapturePhotoSettings.photoSettings()
    # 最高解像度で撮影するか
    # settings.isHighResolutionPhotoEnabled = 0 (BOOL 1=true, 0=false)
    settings.AVCaptureFocusMode = focusMode # フォーカスモード
    time.sleep(0.2)
    # delegateを作成し
    event = threading.Event()
    delegate = CameraManualPhotoCaptureDelegate.new()
    print("delegate is created.")
    print(delegate)
    
    # capturePhotoに、setting, delegateを渡して撮影する
    photoOutput.capturePhotoWithSettings_delegate_(settings, delegate)
    print("done")
    session.stopRunning()
    session.release()
    photoOutput.release()
