
from objc_util import *
import ctypes
from uikit.ui_uiview import *
import numpy as np
import copy
from uikit.ui_uiimage_convert import *
import time

from defines import *

# 処理画像を表示させるための関数
@on_main_thread
def update_image(ui_imageview, image):
    # UIImageViewのimageを更新する
    ui_imageview.image = np2ui(image)
    ui_imageview.setNeedsLayout()

# delegateから呼ばれる処理関数
def processPixelBuffer(pixelData, ui_imageview, user_func, sessionPreset, pixel_format_type):
    base_address  = CVPixelBufferGetBaseAddressOfPlane(pixelData, 0)
    bytes_per_row = CVPixelBufferGetBytesPerRowOfPlane(pixelData, 0)
    # サイズを取得
    width = CVPixelBufferGetWidthOfPlane(pixelData, 0)
    height = CVPixelBufferGetHeightOfPlane(pixelData, 0)
    
    if pixel_format_type is CV32BGRA:
        _image = np.ctypeslib.as_array(
            ctypes.cast(base_address, ctypes.POINTER(ctypes.c_ubyte)),
            shape=((height, width*4)) )
        np_img = copy.copy(_image) # 廃棄防止をしてユーザー関数を呼ぶ
        user_func(np_img)
        update_image(ui_imageview, np_img.reshape(height, width, 4)) # 4色表示(単色ならnp_img[:,::4])
    else: # YUV_420_888のYだけを取得する場合（条件設定は直しましょう）
        _image = np.ctypeslib.as_array(
            ctypes.cast(base_address, ctypes.POINTER(ctypes.c_ubyte)),
            shape=((height, width)) )
        np_img = copy.copy(_image) # 廃棄防止をしてユーザー関数を呼ぶ
        user_func(np_img)
        update_image(ui_imageview, np_img) # np_img⇒UIImage⇒ui_imageview
    
class AVCaptureVideoData_Capture_Ex:
    # コンストラクタ
    def __init__( self,
        ui_view,               # 取得画像を表示するUIView
        captureDeviceType,     # 取得デバイス:
        captureDevicePosition, # 取得デバイス位置
        sessionPreset,         # 取得画像サイズ
        pixel_format_type,     # 画像色フォーマット
        func ):                # 取得画像へ処理を行うユーザ関数
        
        # プロパティの設定
        self.ui_view = ui_view
        self.captureDeviceType = captureDeviceType
        self.captureDevicePosition = captureDevicePosition
        self.sessionPreset = sessionPreset
        self.pixel_format_type = pixel_format_type
        self.user_func = func
        self.processed_frames = None

        # デバイスを開く
        captureDeviceDiscoverySession = AVCaptureDeviceDiscoverySession.discoverySessionWithDeviceTypes_mediaType_position_(
                [self.captureDeviceType], AVMediaTypeVideo,
                self.captureDevicePosition)
        # デバイスを開く
        captureDevices = captureDeviceDiscoverySession.devices()
        self.device = captureDevices[0] # 該当する最初のデバイスを選択
        _input = AVCaptureDeviceInput.deviceInputWithDevice_error_(self.device, None)
        if _input:
            self.session = AVCaptureSession.alloc().init()
            self.session.addInput_(_input)
        else:
            return

        # AVCaptureVideoDataOutput を作成
        self.output = AVCaptureVideoDataOutput.alloc().init()
        if pixel_format_type is not None:
            self.output.videoSettings = {
                kCVPixelBufferPixelFormatTypeKey:pixel_format_type }
        print("videoSettings()")
        print(self.output.videoSettings())
    
        # デバイス設定をロック
        self.device.lockForConfiguration_(None)
        # フォーカス設定（必要であれば）
        #self.device.focusMode = AVCaptureFocusModeLocked
        #self.device.setFocusModeLockedWithLensPosition_completionHandler_( 0.5, None )
        # デバイス設定をアンロック
        self.device.unlockForConfiguration()

        # クラス変数を使ったクロージャで、delegate を書く
        def captureOutput_didOutputSampleBuffer_fromConnection_(
              _self, _cmd, _output, _sample_buffer, _conn):
            # iOSのフレームレート設定が面倒なので、手抜き実装
            if time.time() - self.epoch_time > self.frame_duration:
                self.epoch_time = time.time()
                # サンプルバッファを読み込む
                _imageBuffer = CMSampleBufferGetImageBuffer(_sample_buffer)
                # サンプルバッファをロック
                CVPixelBufferLockBaseAddress(_imageBuffer, 0)
                # 具体的な処理をさせる関数を呼ぶ
                processPixelBuffer(_imageBuffer,
                    self.ui_imageview, self.user_func,
                    self.sessionPreset, self.pixel_format_type)
                # サンプルバッファをアンロック
                CVPixelBufferUnlockBaseAddress(_imageBuffer, 0)
                # 時間更新
                self.processed_frames = self.processed_frames + 1

        # delegate 用クラスを作成する
        sampleBufferDelegate = create_objc_class(
            'sampleBufferDelegate', # クラス名
            methods=[captureOutput_didOutputSampleBuffer_fromConnection_],
            protocols=['AVCaptureVideoDataOutputSampleBufferDelegate'])

        # 画像を取得するdelegateとqueueを設定
        self.delegate = sampleBufferDelegate.new() # 作成済みのdelegate用クラス
        self.queue = ObjCInstance(dispatch_get_current_queue())
        self.output.setSampleBufferDelegate_queue_(self.delegate, self.queue)
        # didOutputSampleBufferを処理中に撮影されたフレームは廃棄sする
        self.output.alwaysDiscardsLateVideoFrames = True

        # session に output を接続
        self.session.addOutput_(self.output)
        # session設定をする
        self.session.beginConfiguration()
        self.session.sessionPreset = sessionPreset
        self.session.commitConfiguration()

    def add_view(self):
        # 表示用のui_viewを追加
        self.main_view = get_view_controllers()[1].view()
        add_uiview_to_mainview(self.ui_view, self.main_view)
        # UIImageViewをui_viewに追加しておく
        self.ui_imageview = UIImageView.alloc().init()
        self.ui_imageview.frame = self.ui_view.bounds()
        add_uiview_to_mainview(self.ui_imageview, self.ui_view)
    
    # カメラ撮影をスタートさせる
    @on_main_thread
    def video_shooting_start(self, frameDuration):
        self.add_view()
        self.epoch_time = time.time()
        self.frame_duration = frameDuration
        self.session.startRunning()
        self.processed_frames = 0

    # カメラ撮影を終了させる
    @on_main_thread
    def video_shooting_close(self, ui_view):
        self.session.stopRunning()
        self.delegate.release()
        self.session.release()
        self.output.release()
        
        # プレビューレイヤーを消す（Noneにはしない）
        remove_uiview_fromsuper(ui_view)
        print( "processed_frames:{}".format(self.processed_frames))
