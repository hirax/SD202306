# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

from classes.header import *
import rubicon_objc
import ctypes

# クラスのインスタンスを作成
CMMotionManager_ = CMMotionManager.alloc().init()
if not CMMotionManager_.isDeviceMotionAvailable():
    print("DeviceMotion in NOT Available.")
    raise
else:
    print("DeviceMotion is Available.")

import time

# 便利のために変数などを用意しておく
CMMotionManager_.deviceMotionUpdateInterval = 0.1 # 単位は秒
deviceMotionUpdateInterval = CMMotionManager_.deviceMotionUpdateInterval

magneticFieldData = []

# センサ値取得時のハンドラー関数を作る
def _handler( _data: ctypes.c_void_p, _error: ctypes.c_void_p ) -> None:
    global accelerometerData
    obj = rubicon_objc.api.ObjCInstance( _data ) # CMDeviceMotion
    magneticField = member(obj, 'magneticField', CMMagneticField)
    magneticFieldData.append( {'x':magneticField.field.x, 'y':magneticField.field.y, 'z':magneticField.field.z} )
handler_block = rubicon_objc.api.Block( _handler )

XArbitraryCorrectedZVertical=2
XArbitraryZVertical=1
XMagneticNorthZVertical=4
XTrueNorthZVertical=8

def startMagneticFieldUpdates():
    CMMotionManager_.startDeviceMotionUpdatesUsingReferenceFrame_toQueue_withHandler_(
        XArbitraryCorrectedZVertical,
        NSOperationQueue.mainQueue,
        handler_block )

def stopMagneticFieldUpdates():
        CMMotionManager_.stopDeviceMotionUpdates()

if __name__ == '__main__':
    # 加速度センサ値を格納する変数を初期化しておく
    accelerometerData.clear()
    # 計測を開始する
    startAccelerometerUpdates()
    # * 秒間計測を続ける
    time.sleep(3) # 単位は秒
    # 計測を終了させる
    stopAccelerometerUpdates()
    # 結果を表示
    print( accelerometerData )
