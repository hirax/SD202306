# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

from classes.header import *
import rubicon_objc
import ctypes

# クラスのインスタンスを作成
CMMotionManager_ = CMMotionManager.alloc().init()
if not CMMotionManager_.isAccelerometerAvailable():
    print("Accelerometer in NOT Available.")
    raise
else:
    print("Accelerometer is Available.")

import time

# 便利のために変数などを用意しておく
CMMotionManager_.accelerometerUpdateInterval = 0.1 # 単位は秒
accelerometerUpdateInterval = CMMotionManager_.accelerometerUpdateInterval
accelerometerData = []

# センサ値取得時のハンドラー関数を作る
def _handler( _data: ctypes.c_void_p, _error: ctypes.c_void_p ) -> None:
    global accelerometerData
    obj = rubicon_objc.api.ObjCInstance( _data ) # CMAcceleration
    # CMAcceleration は構造体なので、返り値などを設定する
    acc = member(obj, 'acceleration', CMAcceleration)
    # 'timestamp' は構造体で無く基本型なので、下記は不要なはず
    ts = member(obj,'timestamp', ctypes.c_double) # NSTimeInterval(s) from booting
    accelerometerData.append( {'x':acc.x, 'y':acc.y, 'z':acc.z, 'at':ts} )
handler_block = rubicon_objc.api.Block( _handler )

def startAccelerometerUpdates():
    CMMotionManager_.startAccelerometerUpdatesToQueue_withHandler_(
        NSOperationQueue.mainQueue,
        handler_block )

def stopAccelerometerUpdates():
        CMMotionManager_.stopAccelerometerUpdates()

if __name__ == '__main__':
    # 加速度センサ値を格納する変数を初期化しておく
    accelerometerData.clear()
    # 計測を開始する
    startAccelerometerUpdates()
    # * 秒間計測を続ける
    time.sleep(3) # 単位は秒
    # 計測を終了させる
    stopAccelerometerUpdates()
    # 結果を表示
    print( accelerometerData )
