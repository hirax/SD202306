# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php


from objc_util import *
import ctypes

import enum
class CLLocationAccuracy(enum.Enum):
    kCLLocationAccuracyBest = 0
    kCLLocationAccuracyNearestTenMeters = 1
    kCLLocationAccuracyHundredMeters = 2
    kCLLocationAccuracyKilometer = 3
    kCLLocationAccuracyThreeKilometers = 4

# enum が動かないときのために
kCLLocationAccuracyBest = 0
kCLLocationAccuracyNearestTenMeters = 1
kCLLocationAccuracyHundredMeters = 2
kCLLocationAccuracyKilometer = 3
kCLLocationAccuracyThreeKilometers = 4

CoreLocation = ctypes.cdll.LoadLibrary(
  "/System/Library/Frameworks/CoreLocation.framework/CoreLocation"
)
CLLocationManager = ObjCClass('CLLocationManager')
CLLocation = ObjCClass('CLLocation')
CLLocationManager_ = CLLocationManager.alloc().init()

locationData = []
headingData = []

def locationManager_didUpdateLocations_( _self, _cmd, _manager, _locations):
        print("called.")

# delegateを作成する
LocationManagerDelegate = create_objc_class(
    'LocationManagerDelegate',                      # 作成する delegate クラスの名称
    methods = [locationManager_didUpdateLocations_], # delegate method
    protocols=['CLLocationManagerDelegate']) # プロトコル指定
CLLocationManagerDelegate_ = LocationManagerDelegate.new()
retain_global(CLLocationManagerDelegate_)
# CLLocationManagerインスタンスに、delegateインスタンスを登録
CLLocationManager_.delegate = CLLocationManagerDelegate_

def requestLocation_():
    global CLLocationManager_
    CLLocationManager_.startUpdatingLocation()
    loc = CLLocationManager_.location()
    #heading = CLLocationManager_.heading()
    CLLocationManager_.stopUpdatingLocation()
    
    if loc:
        ret = {
        'timestamp':str(loc.timestamp().description()),
        'coordinate':{'latitude':loc.coordinate().a,
                      'longitude':loc.coordinate().b},
        'altitude':loc.altitude(),
        'ellipsoidalAltitude':loc.ellipsoidalAltitude(),
        'floor':loc.floor().level(),
        'horizontalAccuracy':loc.horizontalAccuracy(),
        'verticalAccuracy':loc.verticalAccuracy(),
        'sourceInformation':{"isProducedByAccessory":
            loc.sourceInformation().isProducedByAccessory(),
                             "isSimulatedBySoftware":
            loc.sourceInformation().isProducedByAccessory()}
    }
    return ret

def start_update_location_and_heading():
    global CLLocationManager_
    CLLocationManager_.startUpdatingLocation()
    CLLocationManager_.startUpdatingHeading()

def stop_update_location_and_heading():
    global CLLocationManager_
    CLLocationManager_.stopUpdatingLocation()
    CLLocationManager_.stopUpdatingHeading()
    
def request_location_and_heading():
    loc = CLLocationManager_.location()
    hed = CLLocationManager_.heading()
    if loc:
        loc = {
        'timestamp':str(loc.timestamp().description()),
        'coordinate':{'latitude':loc.coordinate().a,
                      'longitude':loc.coordinate().b},
        'altitude':loc.altitude(),
        'ellipsoidalAltitude':loc.ellipsoidalAltitude(),
        'floor':loc.floor().level(),
        'horizontalAccuracy':loc.horizontalAccuracy(),
        'verticalAccuracy':loc.verticalAccuracy(),
        'sourceInformation':{"isProducedByAccessory":
            loc.sourceInformation().isProducedByAccessory(),
                             "isSimulatedBySoftware":
            loc.sourceInformation().isProducedByAccessory()}
    }
    if hed:
        hed = {
        'timestamp':str(hed.timestamp().description()),
        'x':hed.x(),
        'y':hed.y(),
        'z':hed.z(),
        #'CLHeadingComponentValue':hed.CLHeadingComponentValue(),
        'magneticHeading':hed.magneticHeading(),
        'trueHeading':hed.trueHeading(),
        'headingAccuracy':hed.headingAccuracy()}
    
    return loc, hed

