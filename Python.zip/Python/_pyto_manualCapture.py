#from avfoundation.manual_capture import manualCapture as mc
from avfoundation.manual_capture import *

uid = 'test'
ext = '.DNG'
denominator =60  # 1 / denominator (s)
imagefileName = uid+'_iso:050_timescale:{}'.format( denominator )+ext
manualCapture(
    #'AVCaptureDeviceTypeBuiltInUltraWideCamera',
    'AVCaptureDeviceTypeBuiltInWideAngleCamera',
    AVCaptureVideoOrientationLandscapeRight, # 撮影向き
    AVCaptureExposureModeLocked, # 露出設定
    1, denominator, # 1/denominator (秒)
    50,  # ISO値 (23-736)
                                                                                                                                                                                                                                                                                                                  AVCaptureFocusModeLocked, # レンズ焦点モード
    0.7, # 焦点距離（0.0-1.0）
    [6000.0, 0.0 ], # 色温度 [temprature(kelvin), tint=white balance(-150.0 to +150.0)]
    [ AVCaptureTorchModeOff, 0.01 ], # ライト設定
    imagefileName, #画像ファイル名
    None, # 'Pythonista Album', # アルバム名
    ext, # 画像保存形式
    False #True )  # .npy で「も」保存するか
)
