import sys

sys.path.insert(0,'/private/var/mobile/Library/Mobile Documents/com~apple~CloudDocs/Python')

print(sys.path)
